"use client"

import DrawingApp from "../drawing-app"

export default function SyntheticV0PageForDeployment() {
  return <DrawingApp />
}